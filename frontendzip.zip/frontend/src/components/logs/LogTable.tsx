import { ChevronRight } from "lucide-react";

import type { LogEntry } from "../../types/operations";

interface LogTableProps {
  logs: LogEntry[];
  onSelect: (log: LogEntry) => void;
}

export default function LogTable({
  logs,
  onSelect,
}: LogTableProps) {
  return (
    <div className="overflow-hidden rounded-2xl border border-white/8 bg-[#07100c]">
      <div className="overflow-x-auto">
        <table className="w-full min-w-250 text-left font-mono">
          <thead className="border-b border-white/8 bg-white/2">
            <tr className="text-[10px] uppercase tracking-wider text-white/30">
              <th className="px-5 py-4">Timestamp</th>
              <th className="px-5 py-4">Level</th>
              <th className="px-5 py-4">Service</th>
              <th className="px-5 py-4">Message</th>
              <th className="px-5 py-4">Trace</th>
              <th />
            </tr>
          </thead>

          <tbody className="divide-y divide-white/5">
            {logs.map((log) => (
              <tr
                key={log.id}
                onClick={() => onSelect(log)}
                className="group cursor-pointer transition hover:bg-white/2.5"
              >
                <td className="px-5 py-4 text-xs text-white/30">
                  {log.timestamp}
                </td>

                <td className="px-5 py-4 text-xs">
                  <span
                    className={
                      log.level === "ERROR"
                        ? "text-red-400"
                        : log.level === "WARN"
                          ? "text-orange-400"
                          : log.level === "INFO"
                            ? "text-emerald-400"
                            : "text-white/40"
                    }
                  >
                    {log.level}
                  </span>
                </td>

                <td className="px-5 py-4 text-xs text-white/45">
                  {log.service}
                </td>

                <td className="max-w-xl truncate px-5 py-4 text-xs text-white/60">
                  {log.message}
                </td>

                <td className="px-5 py-4 text-xs text-white/25">
                  {log.traceId ?? "—"}
                </td>

                <td className="px-5 py-4">
                  <ChevronRight
                    size={15}
                    className="text-white/15 transition group-hover:translate-x-1 group-hover:text-emerald-400"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {logs.length === 0 && (
        <div className="px-5 py-16 text-center text-sm text-white/30">
          No logs match the current filters.
        </div>
      )}
    </div>
  );
}