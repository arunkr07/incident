import { Search } from "lucide-react";
import type { LogLevel } from "../../types/operations";

interface LogFiltersProps {
  search: string;
  level: LogLevel | "ALL";
  service: string;
  onSearchChange: (value: string) => void;
  onLevelChange: (value: LogLevel | "ALL") => void;
  onServiceChange: (value: string) => void;
  services: string[];
}

export default function LogFilters({
  search,
  level,
  service,
  onSearchChange,
  onLevelChange,
  onServiceChange,
  services,
}: LogFiltersProps) {
  return (
    <div className="rounded-2xl border border-white/8 bg-[#0b1813]/85 p-4">
      <div className="grid gap-3 lg:grid-cols-[1fr_auto_auto]">
        <div className="relative">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-white/25"
          />

          <input
            value={search}
            onChange={(event) =>
              onSearchChange(event.target.value)
            }
            placeholder="Search log messages, trace IDs..."
            className="h-10 w-full rounded-lg border border-white/8 bg-black/10 pl-10 pr-4 text-sm text-white outline-none placeholder:text-white/25 focus:border-emerald-500/30"
          />
        </div>

        <select
          value={service}
          onChange={(event) =>
            onServiceChange(event.target.value)
          }
          className="h-10 rounded-lg border border-white/8 bg-[#0b1813] px-3 text-xs text-white/55 outline-none"
        >
          <option value="ALL">All services</option>

          {services.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>

        <select
          value={level}
          onChange={(event) =>
            onLevelChange(
              event.target.value as LogLevel | "ALL",
            )
          }
          className="h-10 rounded-lg border border-white/8 bg-[#0b1813] px-3 text-xs text-white/55 outline-none"
        >
          <option value="ALL">All levels</option>
          <option value="ERROR">ERROR</option>
          <option value="WARN">WARN</option>
          <option value="INFO">INFO</option>
          <option value="DEBUG">DEBUG</option>
        </select>
      </div>
    </div>
  );
}