import { Copy, X } from "lucide-react";

import type { LogEntry } from "../../types/operations";

interface LogDetailsProps {
  log: LogEntry;
  onClose: () => void;
}

export default function LogDetails({
  log,
  onClose,
}: LogDetailsProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4 backdrop-blur-md">
      <div className="w-full max-w-3xl overflow-hidden rounded-2xl border border-white/10 bg-[#09140f] shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/8 px-6 py-4">
          <div>
            <p className="text-sm font-semibold text-white">
              Log details
            </p>

            <p className="mt-1 font-mono text-xs text-white/30">
              {log.id}
            </p>
          </div>

          <button
            onClick={onClose}
            className="rounded-lg p-2 text-white/35 hover:bg-white/5 hover:text-white"
          >
            <X size={17} />
          </button>
        </div>

        <div className="space-y-5 p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <Detail label="Timestamp" value={log.timestamp} />
            <Detail label="Service" value={log.service} />
            <Detail label="Environment" value={log.environment} />
            <Detail label="Level" value={log.level} />
            <Detail label="Trace ID" value={log.traceId ?? "—"} />
            <Detail
              label="Request ID"
              value={log.requestId ?? "—"}
            />
          </div>

          <div>
            <p className="text-xs uppercase tracking-wider text-white/30">
              Message
            </p>

            <div className="mt-2 rounded-xl border border-white/7 bg-black/20 p-4">
              <p className="font-mono text-sm leading-7 text-white/65">
                {log.message}
              </p>
            </div>
          </div>

          <button
            onClick={() =>
              navigator.clipboard?.writeText(log.message)
            }
            className="flex items-center gap-2 rounded-lg border border-white/8 px-3 py-2 text-xs text-white/50 hover:bg-white/5 hover:text-white"
          >
            <Copy size={14} />
            Copy message
          </button>
        </div>
      </div>
    </div>
  );
}

function Detail({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wider text-white/25">
        {label}
      </p>

      <p className="mt-1 font-mono text-xs text-white/55">
        {value}
      </p>
    </div>
  );
}